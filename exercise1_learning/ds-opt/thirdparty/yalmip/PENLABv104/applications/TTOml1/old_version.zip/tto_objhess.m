function [ddf, userdata] = sdp_objhess(x,Y,userdata)
% Hessians of the objective function and constraints

  ddf = [];


